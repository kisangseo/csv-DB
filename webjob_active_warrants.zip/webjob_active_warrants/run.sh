#!/bin/bash
python run_active_warrants.py